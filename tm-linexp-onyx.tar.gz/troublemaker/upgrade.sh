#!/bin/bash

output=/dev/null

if [ -n "$TS_DEBUG" ] ; then
	output=/dev/stdout
	exec 2>&1
	set -x
fi

SDIR="${BASH_SOURCE%/*}"
test ! -d "$SDIR" && SDIR="$PWD"
. "$SDIR/tools.sh"

install_prereq() {
	local util=$1
	local pkg
	local os

	if [ -e /etc/debian_version ] ; then
		os="deb"
	else
		os="rpm"
	fi

	if [ "$os" = "deb" ] ; then
		apt-get install apt-file
		apt-file update
		pkg=$(apt-file search -l bin/$util | grep -v 'dbg')
#		pkg=$(apt-cache search $util | sed 's/ - .*//') # provides wrong package on Debian 7 and 8
		
		[ -z "$pkg" ] && die "Utility \"$util\" not found in the system and cannot be installed."
		apt-get install -y $pkg >>$output 2>&1 || die "Cannot install \"$pkg\" for prerequisite utility \"$util\"."
	else
		pkg=$(yum -q whatprovides $util | sed 's/^[0-9]\{1,\}://' | \
			awk -F: '{print $1}' | grep -vE '^(Repo|Matched|Filename)|^[[:space:]]*$' | sort -u)

		[ -z "$pkg" ] && die "Utility \"$util\" not found in the system and cannot be installed."
		yum install -y $pkg >>$output 2>&1 || die "Cannot install \"$pkg\" for prerequisite utility \"$util\"."
	fi
}

check_prereq() {
	local util=$1

	which $util >/dev/null 2>&1 || install_prereq $util
}

is_plesk_initialized() {
	test -n "$(sql "SELECT val FROM misc WHERE param='psa_configured'")" || \
	die "Plesk is not initialized.\
\nPlease log in to Plesk, fill in admin data, install license, etc."

	plesk bin license --retrieve 2>/dev/null | \
	grep -qE 'License key must be ordered first|The key is expired and can not be updated' && \
	die "No valid license is installed.\
\nPlease install at least Web Pro or Web Host trial license."

	get_shared_ip >/dev/null # report by itself.
}

### PU1			Read-only files in /usr/local/psa

break_PU1() {

	is_plesk_initialized
	echo -n "."

	[ -e /etc/debian_version ] && [ -z $(which chattr) ] && \
	apt-get install -y e2fsprogs >>$output 2>&1
	check_prereq chattr
	echo -n "."
	chattr +i /usr/local/psa/var/root.controls.lock \
		  /usr/local/psa/admin/sbin/wrapper
}

verify_PU1() {
	! lsattr /usr/local/psa/var/root.controls.lock \
		 /usr/local/psa/admin/sbin/wrapper | grep -q ^----i
}

fix_PU1() {
	chattr -i /usr/local/psa/var/root.controls.lock \
		  /usr/local/psa/admin/sbin/wrapper
}

### PU2			No mysql.servers table

break_PU2() {
	mysqldump -uadmin -p$(cat /etc/psa/.psa.shadow) --create-options \
		--no-data mysql servers > /tmp/mysql-servers.sql

	sql "drop table mysql.servers"
}

verify_PU2() {
	sql "select * from mysql.servers" >/dev/null 2>&1
}

fix_PU2() {
	if [ -e /tmp/mysql-servers.sql ] ; then
		mysql -uadmin -p$(cat /etc/psa/.psa.shadow) -Dmysql < /tmp/mysql-servers.sql
		rm -f /tmp/mysql-servers.sql
	else
		mysql -uadmin -p$(cat /etc/psa/.psa.shadow) -Dmysql <<'SERVERS'
CREATE TABLE `servers` (
  `Server_name` char(64) NOT NULL DEFAULT '',
  `Host` char(64) NOT NULL DEFAULT '',
  `Db` char(64) NOT NULL DEFAULT '',
  `Username` char(64) NOT NULL DEFAULT '',
  `Password` char(64) NOT NULL DEFAULT '',
  `Port` int(4) NOT NULL DEFAULT '0',
  `Socket` char(64) NOT NULL DEFAULT '',
  `Wrapper` char(64) NOT NULL DEFAULT '',
  `Owner` char(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`Server_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='MySQL Foreign Servers table'
SERVERS
	fi
}

### PU3			No main IP on the server

break_PU3() {
	sql "UPDATE IP_Addresses SET main = 'false'"
}

verify_PU3() {
	if [ -n "$(sql "SELECT val FROM misc WHERE param='psa_configured'")" ] ; then 
		sql "SELECT COUNT(*) FROM IP_Addresses WHERE main = 'true'" | grep -q '^1$'
	else 
		return 0;
	fi
}

fix_PU3() {
	plesk bin ipmanage --reread >>$output 2>&1
}



# allow arguments processing only if this script is not sourced by another one. 
if [ "${BASH_SOURCE[0]}" = "${0}" ] ; then

check_args $*
problem_id=$2 

case "$1" in
	"--help") #			Show this help message.
		usage
		;;

	"--list") #			List all available problems.
		list_problems -v
		;;

	"--break") # <PROBLEM_ID>	Break specified problem. Use '--list' to list all problems.
		break_${problem_id}

		problem_report "Pre-upgrade checker reports a problem."
		;;

	"--verify") # <PROBLEM_ID>	Verify specified problem. Use '--list' to list all problems.
		if ! verify_${problem_id} ; then
			echo fail
		else
			echo ok
		fi
		;;

	"--fix") # <PROBLEM_ID>	Fix specified problem. Use '--list' to list all problems.
		fix_${problem_id}
		;;

	"--break-all") #		Break all available problem. Use '--list' to list all problems.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Working on the $problem problem..."
			break_${problem} >>$output
			echo -e "\t\tdone."
		done
		problem_report "Pre-upgrade checker reports a problem."
		;;

	"--verify-all") #		Verify all problems. Note: This is time consuming procedure.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Verifying $problem ..."
			if ! verify_${problem} >/dev/null 2>&1 ; then
				echo -e "\t\tfail"
			else
				echo -e "\t\tok"
			fi
		done
		;;

	"--fix-all") #			Fix all problems.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Fixing $problem ..."
			fix_${problem} >>$output 2>&1
			echo -e "\t\t\tdone."
		done
		;;

	*)
		die "Unknown parameter. Run with --help to list available parameters."
		;;
esac
fi 
