#!/bin/bash

output=/dev/null

if [ -n "$TS_DEBUG" ] ; then
	output=/dev/stdout
	exec 2>&1
	set -x
fi

SDIR="${BASH_SOURCE%/*}"
test ! -d "$SDIR" && SDIR="$PWD"
. "$SDIR/tools.sh"

find_httpd() { 
	if [ -e "/etc/debian_version" ] ; then
		echo apache2
	else
		echo httpd
	fi
}

### WEB1			403 Forbidden

break_WEB1() {
	local problem_domain="broken-web-1.tld"

	create_domain $problem_domain
	cat > $VHOSTS_D/$problem_domain/httpdocs/.htaccess <<'HTACCESS'
<IfModule mod_rewrite.c>

RewriteEngine On
RewriteCond !{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

</IfModule>
HTACCESS
	chmod 600 $VHOSTS_D/$problem_domain/httpdocs/.htaccess

	problem_report "Error 403 Forbidden when visiting $problem_domain (IP: $(get_shared_ip))"
}

verify_WEB1() {
	local problem_domain="broken-web-1.tld"
	local rc

	if ! service $httpd status >>$output 2>&1 || \
		! service nginx status >>$output 2>&1 ; then 
		return 64; # cannot verify 
	fi

	if ! grep -q $problem_domain /etc/hosts ; then 
		echo "$(get_shared_ip)		$problem_domain" >>/etc/hosts
	fi

	curl -sLI http://$problem_domain 2>&1 | head -n 1 | grep -q "200 OK"
	rc=$?

	sed -i "/$problem_domain/d" /etc/hosts

	return $rc
}

fix_WEB1() {
	local problem_domain="broken-web-1.tld"
	chown $(stat --printf="%U" $VHOSTS_D/$problem_domain/httpdocs):psacln $VHOSTS_D/$problem_domain/httpdocs/.htaccess
	chmod 644 $VHOSTS_D/$problem_domain/httpdocs/.htaccess
}

### WEB2			502 Bad gateway

break_WEB2() {
	local problem_domain="broken-web-2.tld"
	local fpm_handler=$(plesk bin php_handler --list | awk '$1~/fpm/ && $NF == "enabled" {print $1}' | tail -n 1)

	[ -z "$fpm_handler" ] && die "This exercise requires at least one PHP-FPM handler enabled."

	create_domain $problem_domain
	plesk bin domain --update $problem_domain -php_handler_id $fpm_handler -nginx-serve-php true >>$output 2>&1
	rm -f $VHOSTS_D/$problem_domain/httpdocs/index.htm*
	echo "<?php phpinfo();" > $VHOSTS_D/$problem_domain/httpdocs/index.php
	service $fpm_handler stop >>$output 2>&1

	problem_report "Error 502 Bad Gateway when visiting $problem_domain (IP: $(get_shared_ip))"
}

verify_WEB2() {
	local problem_domain="broken-web-2.tld"
	local rc

	if ! service $httpd status >>$output 2>&1 || \
		! service nginx status >>$output 2>&1 ; then 
		return 64; # cannot verify 
	fi

	if ! grep -q $problem_domain /etc/hosts ; then 
		echo "$(get_shared_ip)		$problem_domain" >>/etc/hosts
	fi

	curl -sLI http://$problem_domain 2>&1 | head -n 1 | grep -q "200 OK"
	rc=$?

	sed -i "/$problem_domain/d" /etc/hosts

	return $rc
}

fix_WEB2() {
	local problem_domain="broken-web-2.tld"
	local fpm_handler=$(sql "SELECT php_handler_id FROM hosting, domains WHERE dom_id=id AND name = '$problem_domain'")

	service $fpm_handler start >>$output 2>&1
}

### WEB3			Apache does not start (1)

break_WEB3() {
	local problem_domains="broken-web-3a.tld broken-web-3b.tld broken-web-3c.tld"
	local problem_domain

	for problem_domain in $problem_domains ; do
		create_domain $problem_domain
		rm -rf $VHOSTS_D/system/$problem_domain/logs/
	done

	problem_report "Unable to start Apache web server: \
$(service $httpd stop 2>&1 && service $httpd start 2>&1)"
}

verify_WEB3() {
	service $httpd start >>$output 2>&1
}

fix_WEB3() {
	plesk repair fs -y >>$output 2>&1
	service $httpd start >>$output 2>&1
}

### WEB4			Apache does not start (2)

break_WEB4() {
	plesk sbin nginxmng --enable >>$output 2>&1

	service $httpd stop

	find $HTTPD_CONF_D $HTTPD_INCLUDE_D -type f -name '*.conf' -exec \
	     sed -i -e 's/^Listen[[:space:]]\{1,\}7080/Listen 80/g' \
		    -e 's/^Listen[[:space:]]\{1,\}7081/Listen 443/g' '{}' \;

	problem_report "Unable to start Apache web server: \
$(service $httpd stop 2>&1 && service $httpd start 2>&1)"
}

verify_WEB4() {
	service nginx start >>$output 2>&1 && \
		service $httpd start >>$output 2>&1
}

fix_WEB4() {
	plesk sbin nginxmng --disable && plesk sbin nginxmng --enable
}

### WEB5			Apache does not start (3)

break_WEB5() {
	local nginx_status=$(plesk sbin nginxmng --status)
	local port

	if [ "$nginx_status" = "Enabled" ] ; then
		port=7080
	else
		port=80
	fi

	echo "Listen $port" >$HTTPD_INCLUDE_D/00_ports.conf

	problem_report "Unable to start Apache web server: \
$(service $httpd stop 2>&1 && service $httpd start 2>&1)"
}

verify_WEB5() {
	service $httpd stop >>$output 2>&1
	service $httpd start >>$output 2>&1
	sleep 2s # delay is required for Debian 7
	service $httpd status >>$output 2>&1
}

fix_WEB5() {
	rm -f $HTTPD_INCLUDE_D/00_ports.conf
	service $httpd stop >>$output 2>&1
	service $httpd start >>$output 2>&1
}

### WEB6			Apache and nginx do not start

break_WEB6() {
	rm -f /usr/local/psa/var/certificates/*

	problem_report "Apache and nginx web servers do not start: \
$(service $httpd stop 2>&1 && service $httpd start 2>&1) \
$(service nginx stop 2>&1 && service nginx start 2>&1)"
}

verify_WEB6() {
	service nginx start >>$output 2>&1 && service $httpd start >>$output 2>&1
}

fix_WEB6() {
	plesk repair web -y >>$output 2>&1
}

### RANDOM			Random problem

break_RANDOM() {	# Random problem
	local tmpfile=$(mktemp /tmp/db_random_break.XXX)
	local max problem

	list_problems | grep -v ^RANDOM > $tmpfile
	max=$(wc -l $tmpfile | cut -d" " -f1)

	problem=$(head -n $[RANDOM % $max + 1] $tmpfile | tail -n 1)

	rm $tmpfile

	break_${problem}
}

VHOSTS_D=$(psa_conf HTTPD_VHOSTS_D)
HTTPD_CONF_D=$(psa_conf HTTPD_CONF_D)
HTTPD_INCLUDE_D=$(psa_conf HTTPD_INCLUDE_D)
httpd=$(find_httpd)

check_args $*
problem_id=$2 

case "$1" in
	"--help") #			Show this help message.
		usage
		;;

	"--list") #			List all available problems.
		list_problems -v
		;;

	"--break") # <PROBLEM_ID>		Break specified problem. Use '--list' to list all problems.
		break_${problem_id}
		;;

	"--verify") # <PROBLEM_ID>		Verify specified problem. Use '--list' to list all problems.
		verify_${problem_id} >>$output
		rc=$?

		if [ $rc -eq 0 ] ; then
			echo -e "ok"
		elif [ $rc -eq 64 ] ; then 
			echo -e "Cannot verify. Resolve other issues first."
		else
			echo -e "fail"
		fi
		;;

	"--fix") # <PROBLEM_ID>		Fix specified problem. Use '--list' to list all problems.
		fix_${problem_id}
		;;

	"--break-all") #			Break all available problem. Use '--list' to list all problems.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Working on the $problem problem..."
			break_${problem} >>$output 2>&1
			echo -e "\tdone."
		done
		;;

	"--verify-all") #			Verify all problems. Note: This is time consuming procedure.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Verifying $problem ..."
			verify_${problem} >>$output
			rc=$?

			if [ $rc -eq 0 ] ; then
				echo -e "\t\tok"
			elif [ $rc -eq 64 ] ; then 
				echo -e "\t\tCannot verify. Resolve other issues first."
			else
				echo -e "\t\tfail"
			fi
		done
		;;
	
	"--fix-all") #			Fix all problems.
		echo "It may take few minutes. Please wait."
		for problem in WEB3 WEB5 WEB6 WEB4 WEB1 WEB2 ; do 
			echo -n "Fixing $problem ..."
			fix_${problem}
			echo -e "\t\t\tdone."
		done
		;;

	*)
		die "Unknown parameter. Run with --help to list available parameters."
		;;
esac

