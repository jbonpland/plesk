#!/bin/bash

output=/dev/null

if [ -n "$TS_DEBUG" ] ; then
	output=/dev/stdout
	exec 2>&1
	set -x
fi

SDIR="${BASH_SOURCE%/*}"
test ! -d "$SDIR" && SDIR="$PWD"
. "$SDIR/tools.sh"

### FRONT_1			502 Bad Gateway

break_FRONT_1() {
	chown root:root /var/run/sw-engine.sock

	problem_report "Cannot access Plesk interface - error 502 is showing."
}

verify_FRONT_1() {
	if [ "$(stat --printf="%U" /var/run/sw-engine.sock)" = "sw-cp-server" ] ; then
		return 0
	else
		return 1
	fi
}

fix_FRONT_1() {
	chown sw-cp-server:root /var/run/sw-engine.sock
	service sw-engine restart >>$output 2>&1
}

### FRONT_2			Cannot access Plesk control panel

break_FRONT_2() {
	sed -i 's/8443/443/g' /etc/sw-cp-server/conf.d/plesk.conf
	service sw-cp-server restart >>$output 2>&1

	problem_report "Cannot access Plesk control panel."
}

verify_FRONT_2() {
	service sw-cp-server status >>$output 2>&1
}

fix_FRONT_2() {
	sed -i 's/[[:space:]]443/ 8443/g' /etc/sw-cp-server/conf.d/plesk.conf
	service sw-cp-server restart >>$output 2>&1
}

### BACK_1			Permission Denied errors in Plesk when trying to manage services

break_BACK_1() {
	chown psaadm:psaadm /usr/local/psa/admin/sbin/wrapper
	chmod 755 /usr/local/psa/admin/sbin/wrapper

	problem_report "Cannot restart web server via Plesk - Permission denied error."
}

verify_BACK_1() {
	if [ "$(stat --printf="%U:%G %a" /usr/local/psa/admin/sbin/wrapper)" = "root:psaadm 4110"  ] ; then
		return 0
	else
		return 1
	fi
}

fix_BACK_1() {
	chown root:psaadm /usr/local/psa/admin/sbin/wrapper
	chmod 4110 /usr/local/psa/admin/sbin/wrapper
}

### BACK_2			Permission Denied errors in Plesk when trying to install updates

break_BACK_2() {
	kill_installer

	echo -n > /usr/local/psa/admin/sbin/autoinstaller

	problem_report "Cannot install updates - Tools & Settings > Updates and Upgrades does not work"
}

verify_BACK_2() {
	kill_installer
	plesk installer --version >/dev/null 2>&1
}

fix_BACK_2() {
	wget -qq http://autoinstall.plesk.com/plesk-installer >>$output 2>&1
	chmod +x ./plesk-installer
	./plesk-installer --version >/dev/null 2>&1
	mv /var/cache/parallels_installer/installer /usr/local/psa/admin/sbin/autoinstaller
	rm -f ./plesk-installer
}

### RANDOM			Random problem

break_RANDOM() {	# Random problem
	local tmpfile=$(mktemp /tmp/db_random_break.XXX)
	local max problem

	list_problems | grep -v ^RANDOM > $tmpfile
	max=$(wc -l $tmpfile | cut -d" " -f1)

	problem=$(head -n $[RANDOM % $max + 1] $tmpfile | tail -n 1)

	rm $tmpfile

	break_${problem}
}

check_args $*
problem_id=$2 

case "$1" in
	"--help") #			Show this help message.
		usage
		;;

	"--list") #			List all available problems.
		list_problems -v
		;;

	"--break") # <PROBLEM_ID> 	Break specified problem. Use '--list' to list all problems.
		break_${problem_id}
		;;

	"--verify") # <PROBLEM_ID>	Verify specified problem. Use '--list' to list all problems.
		if ! verify_${problem_id} ; then
			echo fail
		else
			echo ok
		fi
		;;

	"--fix") # <PROBLEM_ID>		Fix specified problem. Use '--list' to list all problems.
		fix_${problem_id}
		;;

	"--break-all") #			Break all available problem. Use '--list' to list all problems.
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Working on the $problem problem..."
			break_${problem} >>$output 2>&1
			echo -e "\tdone."
		done
		;;

	"--verify-all") #		Verify all problems. Note: This is time consuming procedure.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Verifying $problem ..."
			verify_${problem} >/dev/null 2>&1
			rc=$?

			if [ $rc -ne 0 ] ; then
				echo -e "\t\tfail"
			else
				echo -e "\t\tok"
			fi
		done
		;;
	
	"--fix-all") #			Fix all problems.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Fixing $problem ..."
			fix_${problem}
			echo -e "\t\tdone."
		done
		;;

	*)
		die "Unknown parameter. Run with --help to list available parameters."
		;;
esac

