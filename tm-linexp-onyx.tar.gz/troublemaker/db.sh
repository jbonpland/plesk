#!/bin/bash

output=/dev/null

if [ -n "$TS_DEBUG" ] ; then
	output=/dev/stdout
	exec 2>&1
	set -x
fi

SDIR="${BASH_SOURCE%/*}"
test ! -d "$SDIR" && SDIR="$PWD"
. "$SDIR/tools.sh"

get_mysql_service_name() {
        local service

#OLD       for service in mysql mysqld mariadb ; do
        if which systemctl >/dev/null 2>&1 ; then
#OLD 		systemctl status $service 2>&1 | grep -q "Loaded: loaded" && break
			service="$(systemctl list-unit-files | grep enabled | \
			 grep -owE 'mysql|mysqld|mariadb')"
			test -z "$service" && for service in mysql mysqld mariadb ; do
				systemctl status $service 2>&1 | grep -q "Loaded: loaded" && break
			done
        elif which chkconfig >/dev/null 2>&1 ; then
#OLD            chkconfig --list $service 2>&1 | grep -q :on && break
                service="$(chkconfig --list | grep ':on' | \
			 grep -owE 'mysql|mysqld|mariadb')"
        elif which initctl >/dev/null 2>&1 ; then
                service="$(initctl list | \
			 grep -owE 'mysql|mysqld|mariadb')" # Ubuntu 14
        else
                die "Cannot get active MySQL service name."
        fi
#OLD       done
		test -z "$service" && die "Cannot get active MySQL service name."
        echo $service
}

find_my_cnf()
{
        local cnf_files="/etc/my.cnf /etc/mysql/my.cnf /var/db/mysql/my.cnf"

        for my_cnf in $cnf_files; do
                if [ -f ${my_cnf} ]; then
			echo $my_cnf
                        break
                fi
        done
}

### MYSQL_DOWN		MySQL service does not start

break_MYSQL_DOWN() {
	service $mysql_service stop >>$output 2>&1
	chown -R root:root $MYSQL_VAR_D >>$output 2>&1
	service $mysql_service start >>$output 2>&1

	problem_report "MySQL service does not start."
}

verify_MYSQL_DOWN() {
	service $mysql_service stop >/dev/null 2>&1
	if ! service $mysql_service start >/dev/null 2>&1 ; then
		return 1
	else
		return 0
	fi
}

fix_MYSQL_DOWN() {
	chown -R mysql:mysql $MYSQL_VAR_D
	service $mysql_service start >>$output 2>&1
}

### MYSQL_AUTH		Cannot login to Plesk control panel.

break_MYSQL_AUTH() {	
	local random_password=$(genpass 12)
	sql "UPDATE mysql.user SET Password=password('$random_password') WHERE User='admin'"
	service $mysql_service restart >>$output 2>&1

	problem_report "Cannot login to Plesk control panel."
}

verify_MYSQL_AUTH() {
	if grep -q "^[[:space:]]*skip-grant-tables" $my_cnf ; then
		return 1
	elif ! sql "SHOW TABLES" >/dev/null 2>&1 ; then
		return 1
	else
		return 0
	fi
}

fix_MYSQL_AUTH() {
	local admin_pass=$(cat /etc/psa/.psa.shadow)

	if ! grep -q ^skip-grant-tables $my_cnf ; then
		sed -i '/\[mysqld\]/a \
skip-grant-tables' $my_cnf
	fi

	service $mysql_service restart >>$output 2>&1

	mysql -e"UPDATE mysql.user SET Password=password('$admin_pass') WHERE User='admin'"

	sed -i '/skip-grant-tables/d' $my_cnf
	service $mysql_service restart >>$output 2>&1
}

### DB1			Error in Plesk when opening a subscription

break_DB1() {
	local broken_domain="dbproblem1.tld"

	create_domain $broken_domain

	sql "DELETE FROM sys_users WHERE id = (SELECT h.sys_user_id FROM hosting h, domains d WHERE d.id = h.dom_id AND d.name = '$broken_domain')"

	problem_report "Unable to open subscription '$broken_domain' in Plesk."
}

verify_DB1() {
	local broken_domain="dbproblem1.tld"
	local n

#	if ! service $mysql_service status || ! pgrep $mysql_service; then # it is working on Debian 8, but does not work on CentOS 7
	if ! service $mysql_service status; then # does not work on Debian 8
		return 64; # cannot verify 
	fi
	
	if [ ! -d $VHOSTS_D/$broken_domain ] ; then
		return 0
	fi

	n=$(sql "SELECT COUNT(*) FROM domains d JOIN hosting h ON h.dom_id = d.id JOIN sys_users s ON s.id = h.sys_user_id JOIN accounts a ON a.id = s.account_id WHERE d.name = '$broken_domain'")

	if [ "$n" = "1" ] ; then
		return 0
	else
		return 1
	fi
}

fix_DB1() {
	local broken_domain="dbproblem1.tld"
	local id login account_id home shell
	
	if ! grep -q "$broken_domain" /etc/passwd; then
		echo "Nothing to fix."
		return 0
	fi
	
	id=$(sql "SELECT sys_user_id FROM hosting, domains WHERE dom_id = id AND name = '$broken_domain'")
	login=$(grep /$broken_domain: /etc/passwd | cut -d: -f1)
	account_id=$(sql "INSERT INTO accounts (password) VALUES ('$(genpass)'); SELECT LAST_INSERT_ID()")
	home=$(grep /$broken_domain: /etc/passwd | cut -d: -f6)
	shell=$(grep /$broken_domain: /etc/passwd | cut -d: -f7)

	sql "INSERT INTO sys_users (id, serviceNodeId, login, account_id, home, shell) VALUES ($id, 1, '$login', $account_id, '$home', '$shell')"
	plesk bin domain --update $broken_domain -passwd "$(genpass)" >>$output 2>&1
}

### DB2			Unable to open file manager

break_DB2() {
	local broken_domain="dbproblem2.tld"

	create_domain $broken_domain

	sql "DELETE FROM hosting WHERE dom_id = (SELECT id FROM domains WHERE name = '$broken_domain')"

	problem_report "Unable to open file manager for domain '$broken_domain' in Plesk."
}

verify_DB2() {
	local broken_domain="dbproblem2.tld"
	local n

#	if ! service $mysql_service status || ! pgrep $mysql_service; then # it is working on Debian 8, but does not work on CentOS 7
	if ! service $mysql_service status; then # does not work on Debian 8
		return 64; # cannot verify 
	fi

	if [ ! -d $VHOSTS_D/$broken_domain ] ; then
		return 0
	fi

	n=$(sql "SELECT COUNT(*) FROM domains d JOIN hosting h ON h.dom_id = d.id JOIN sys_users s ON s.id = h.sys_user_id JOIN accounts a ON a.id = s.account_id WHERE d.name = '$broken_domain' AND h.www_root = CONCAT(s.home, '/httpdocs')")

	if [ "$n" = "1" ] ; then
		return 0
	else
		return 1
	fi
}

fix_DB2() {
	local broken_domain="dbproblem2.tld"
	local dom_id www_root sys_user_id 

	if ! grep -q "$broken_domain" /etc/passwd; then
		echo "Nothing to fix."
	fi

	dom_id=$(sql "SELECT id FROM domains WHERE name = '$broken_domain'")
	sys_user_id=$(sql "SELECT id FROM sys_users WHERE home LIKE '%/$broken_domain'")
	www_root=$(sql "SELECT CONCAT(home, '/httpdocs') FROM sys_users WHERE id = $sys_user_id")
	
	sql "INSERT INTO hosting (dom_id, sys_user_id, www_root) VALUES ($dom_id, $sys_user_id, '$www_root')"
	plesk bin subscription --unlock-subscription $broken_domain >>$output 2>&1
	plesk bin subscription --sync-subscription $broken_domain >>$output 2>&1
}

### DB3			Error in Plesk when customer tries to create a domain

break_DB3() {
	local login="br_cust"
	local company="Plesk"
	local customer="Broken Customer"

	plesk bin client --create "$login" \
		-company "$company" \
		-name "$customer" \
		-passwd "$(genpass)" \
		-email "$login@edu.trn" \
		-phone "+1 800 555 1234" \
		-notify false >>$output 2>&1

	if [ $? -eq 1 ] ; then
		plesk bin client --remove $login >>$output 2>&1

		plesk bin client --create "$login" \
			-company "$company" \
			-name "$customer" \
			-passwd "$(genpass)" \
			-email "$login@edu.trn" \
			-phone "+1 800 555 1234" \
			-notify false >>$output 2>&1
	fi

	plesk bin domain --create "broken-customer.tld" \
		-service_plan "Default domain" \
		-owner $login \
		-hosting true \
		-ip $(get_shared_ip) \
		-login "ftp_$RANDOM" \
		-passwd "$(genpass)" \
		-notify false >>$output 2>&1

	sql "SET @max_ip = (SELECT MAX(id) FROM IP_Addresses) + 1; SET @pool_id = (SELECT pool_id FROM clients WHERE login = '$login'); INSERT INTO ip_pool (id, ip_address_id, type) VALUES (@pool_id, @max_ip, 'shared');"

	problem_report "Cannot create new domain for customer '$customer'. Go to Plesk, login as customer and try to add a new domain."
}

verify_DB3() {
	local n

#	if ! service $mysql_service status || ! pgrep $mysql_service; then # it is working on Debian 8, but does not work on CentOS 7
	if ! service $mysql_service status; then # does not work on Debian 8
		return 64; # cannot verify 
	fi

	n=$(sql "SELECT COUNT(*) FROM ip_pool p LEFT JOIN IP_Addresses i ON i.id = p.ip_address_id WHERE i.id IS NULL")

	if [ "$n" = "0" ] ; then
		return 0
	else
		return 1
	fi
}

fix_DB3() {
	plesk repair db -y >>$output 2>&1
}

### DB4			Missing 'Mail' tab on a domain

break_DB4() {
	local broken_domain="no-mail-tab.tld"

	create_domain $broken_domain
	plesk db dump > /tmp/$broken_domain.dump.sql

	sql "DELETE FROM DomainServices WHERE type = 'mail' AND dom_id = (SELECT id FROM domains WHERE name = '$broken_domain')"

	problem_report "There's no 'Mail' tab in Plesk for domain '$broken_domain'."
}

verify_DB4() {
	local broken_domain="no-mail-tab.tld"
	local n

#	if ! service $mysql_service status || ! pgrep $mysql_service; then # it is working on Debian 8, but does not work on CentOS 7
	if ! service $mysql_service status; then # does not work on Debian 8
		return 64; # cannot verify 
	fi

	if [ ! -d $VHOSTS_D/$broken_domain ] ; then
		return 0
	fi

	n=$(sql "SELECT COUNT(*) FROM domains d JOIN DomainServices ds ON ds.dom_id = d.id WHERE ds.type = 'mail' AND d.name = '$broken_domain'")

	if [ "$n" = "1" ] ; then
		return 0
	else
		return 1
	fi
}

fix_DB4() {
	local broken_domain="no-mail-tab.tld"

	wget -qq http://kb.odin.com/Attachments/kcs-506/mail_restore.sh -O /tmp/mail_restore.sh >>$output 2>&1
	bash /tmp/mail_restore.sh $broken_domain >>$output 2>&1
}

### RANDOM			Random problem

break_RANDOM() {	# Random problem
	local tmpfile=$(mktemp /tmp/db_random_break.XXX)
	local max problem

	list_problems | grep -v ^RANDOM > $tmpfile
	max=$(wc -l $tmpfile | cut -d" " -f1)

	problem=$(head -n $[RANDOM % $max + 1] $tmpfile | tail -n 1)

	rm $tmpfile

	break_${problem}
}

MYSQL_VAR_D=$(psa_conf MYSQL_VAR_D)
VHOSTS_D=$(psa_conf HTTPD_VHOSTS_D)
mysql_service=$(get_mysql_service_name)
my_cnf=$(find_my_cnf)

check_args $*
problem_id=$2 

case "$1" in
	"--help") #				Show this help message.
		usage
		;;

	"--list") #				List all available problems.
		list_problems -v
		;;

	"--break") # <PROBLEM_ID> 		Break specified problem. Use '--list' to list all problems.
		break_${problem_id}
		;;

	"--verify") # <PROBLEM_ID>		Verify specified problem. Use '--list' to list all problems.
		verify_${problem_id} >>$output
		rc=$?

		if [ $rc -eq 0 ] ; then
			echo -e "ok"
		elif [ $rc -eq 64 ] ; then 
			echo -e "Cannot verify. Resolve other issues first."
		else
			echo -e "fail"
		fi
		;;

	"--fix") # <PROBLEM_ID>		Fix specified problem. Use '--list' to list all problems.
		fix_${problem_id}
		;;

	"--break-all") #			Break all available problem. Use '--list' to list all problems.
		for problem in $(list_problems | grep -v ^RANDOM | tac) ; do # tac - to reverse problems order
			echo -n "Working on the $problem problem..."
			break_${problem} >>$output 2>&1
			echo -e "\tdone."
		done
		;;

	"--verify-all") #			Verify all problems. Note: This is time consuming procedure.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Verifying $problem ..."
			verify_${problem} >/dev/null 2>&1
			rc=$?

			if [ $rc -eq 0 ] ; then
				echo -e "\t\tok"
			elif [ $rc -eq 64 ] ; then 
				echo -e "\t\tCannot verify. Resolve other issues first."
			else
				echo -e "\t\tfail"
			fi
		done
		;;
	
	"--fix-all") #			Fix all problems.
		echo "It may take few minutes. Please wait."
		for problem in $(list_problems | grep -v ^RANDOM) ; do
			echo -n "Fixing $problem ..."
			fix_${problem}
			echo -e "\t\tdone."
		done
		;;

	*)
		die "Unknown parameter. Run with --help to list available parameters."
		;;
esac

