#!/bin/bash

output=/dev/null

if [ -n "$TS_DEBUG" ] ; then
	output=/dev/stdout
	exec 2>&1
	set -x
fi

SDIR="${BASH_SOURCE%/*}"
test ! -d "$SDIR" && SDIR="$PWD"
. "$SDIR/upgrade.sh"

form_undotted_version()
{
# Backward compatible with versions < 11.1.11
        local major=`cut -d" " -f1 /usr/local/psa/version | awk -F. '{ print $1 }'`
        local minor=`cut -d" " -f1 /usr/local/psa/version | awk -F. '{ print $2 }'`
        local patch=`cut -d" " -f1 /usr/local/psa/version | awk -F. '{ print $3 }'`
        if [ -z "$major" -o -z "$minor" -o -z "$patch" ]; then
                return 1
        fi

        if [ $major -lt 11 ] ; then
                echo "${major}${minor}"
        elif [ $major -eq 11 -a $minor -lt 1 ] || [ $major -eq 11 -a $minor -eq 1 -a $patch -lt 11 ]; then
                printf "%d%02d" $major $minor
        else
                printf "%03d%03d%03d" $major $minor $patch
        fi
}

### FAILED_UPGRADE		Failed upgrade

break_FAILED_UPGRADE() {
	local dump

	echo -n "Breaking the upgrade. Please wait "
	kill_installer

	if ! uname -a | grep '86_64' >>$output 2>&1; then
		die "Cannot break the upgrade. \
Latest Plesk version does not support 32-bit Operating Systems. \
See https://docs.plesk.com/release-notes/17.0/software-requirements/ for details."
	fi
	if ! plesk installer --show-releases 2>/dev/null | grep 'PLESK_17' >>$output 2>&1; then
			die "Cannot break the upgrade. \
Latest Plesk version cannot be installed on the current Operating System. \
See https://docs.plesk.com/release-notes/17.0/software-requirements/ for details."
	fi
	for problem in PU1 PU2 PU3 ; do
	break_${problem} >/dev/null 2>&1
	echo -n "."
	done

	if verify_PU1 && verify_PU2 && verify_PU3 ; then
		die "Cannot break the upgrade."
	fi

	plesk installer --select-product-id plesk --select-release-latest --upgrade-installed-components --skip-components-check >>$output 2>&1
	echo -n "."
	
	dump=$(find /var/lib/psa/dumps/ -name 'mysql.preupgrade.*.dump.gz' ! -name '*apsc*' | sort | head -n 1)
	zcat $dump | plesk db
	echo -n "."

	for f in /usr/local/psa/version /usr/local/psa/core.version ; do
		cp $f $f.bak
		awk '{$1="12.5.30";print}' $f.bak > $f
		rm -f $f.bak
	done
	echo -e "\tdone."

	problem_report "Upgrade to Onyx had failed."
}

verify_FAILED_UPGRADE() {
	local db_version
	local psa_version

	db_version=$(sql "SELECT val FROM misc WHERE param = 'version'")
	psa_version=$(form_undotted_version)

	if [ "0$db_version" -ne "0$psa_version" ] ; then
		return 1
	else
		return 0
	fi
}

fix_FAILED_UPGRADE() {
	echo -n "Applying partial fix"
	for problem in PU1 PU2 PU3 ; do
		fix_${problem}
		echo -n "."
	done
	echo -e "\tdone."
	echo "Further, failed upgrade must be fixed manually. Use instructions provided in the training."
}

test -n "$1" || die "Parameter is required. Run with --help to list available parameters."

case "$1" in
	"--break") #		Break upgrade.
		break_FAILED_UPGRADE
		;;

	"--verify") #		Verify whether all issues are fixed or not.
		if ! verify_FAILED_UPGRADE ; then
			echo fail
		else
			echo ok
		fi
		;;
	
	"--fix") # 		Fix all issues that are possible to fix.
		fix_FAILED_UPGRADE
		;;

	"--list") #		List all available problems.
		list_problems -v
		;;

	"--help") #		Show this help message.
		usage
		;;

	*)
		die "Unknown parameter. Run with --help to list available parameters."
		;;
esac

