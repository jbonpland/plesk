#!/bin/bash

# This module contains the following functions:
#  problem_report - displays emphasized problem report.
#  err		 	  - displays error message without script interruption.
#  die			  - displays error message and terminates script.
#  list_problems  - list problems' IDs along with their description.
#  sql			  - executes PSA database request.
#  psa_conf		  - returns value of a variable from psa.conf 
#  genpass		  - generates Strong or Very Strong passwords.
#  get_shared_ip  - returns first found shared IP address.
#  create_domain  - creates domain and [optional] assignes it to a client.
#  kill_installer - kills autoinstaller and installer instances.
#  usage		  - list available options
#  check_args	  - checking arguments for --break/verify/fix options.

problem_report() {
# This function displays emphasized problem report.
# Usage:
#
# problem_report "Oops, you have a problem."
#
cat <<REPORT

------------------------------------------------------------------------

$*

------------------------------------------------------------------------

REPORT
}

err() {
# This function displays error message without script interruption.
# Usage:
#
# err "Default IP not found.\t\t" $result
#
	echo -e "\n$*" >&2
}

die() {
# This function displays error message and terminates script.
# Usage:
#
# die "Default IP not found." $result
#
	echo -e "\nFATAL: $*" >&2
	exit 1
}

list_problems() {
# This function lists problems' IDs along with their description 
# which are contained in a file where it was invoked from.
# It assumes the following syntax of comment in the source script: 
#
# ^###<space><Problem_ID><TAB>...<TAB><Description of the problem.>
#
# Note1: '^' represents beginning of the line.
# Note2: Number of <TAB>s between problem ID and description depends on 
# the problem ID length and vary from 1 (for long names) to 3 (for short names).
# '-v' - show header and problems with their description.
# Usage:
#
# list_problems [-v]
#
	if [ "$1" = "-v" ] ; then
		echo -e "PROBLEM_ID\t\tDescription"
		echo -e "----------\t\t----------------------------"
		grep -E '^### ' $0 | sed -e 's/^### //'
	else
		grep -E '^### ' $0 | awk '{print $2}'
	fi
}

sql() {
# This function executes PSA database request.
# Usage:
#
# sql "SELECT `login` FROM `clients` WHERE `pname`=\"C num 5\""
#
# NOTE: double quotes (") inside of the request must be escaped with '\' 
#   to submit quote to mysql. 
#
	MYSQL_PWD=`cat /etc/psa/.psa.shadow` mysql -uadmin -Ns -Dpsa -e"$1"
}

psa_conf() {
# This function returns value of the variables from psa.conf
# Usage:
# 
# psa_conf HTTPD_VHOSTS_D
#
	local RESULT="$(grep "^$1[[:space:]]" /etc/psa/psa.conf | awk '{print $NF}')"
	test -z "$RESULT" && die "Cannot find $1 in psa.conf. \
		See https://kb.plesk.com/en/952 for example configuration."
	echo "$RESULT"
}

genpass() {
# This function generates Strong or Very Strong password.
	local len=${1:-12}
	
	strings /dev/urandom | head -n 100 | \
	sed -n '
		H;
		${
			x;
			s/[^a-z0-9_.#@%-]//ig;			# leave only alphanumerics, _, @, &, *, +, %, =, ~, . and /
			s/\([a-z]\)[a-z]*/\1/ig;		# no sequential letters together
			s/\([0-9]\)[0-9]*/\1/g;			# same for numbers
			p
		}' | cut -c1-$len
}

get_shared_ip() {
# This function returns first found shared IP address
# or returns error. 
	local ip

	ip=$(plesk bin ipmanage -l | awk '$2=="S" {print $3}' | head -n 1 | sed -e 's/^[^:]*:\([^/]*\).*/\1/')

	[ -z "$ip" ] && die "You need to have at least one shared IP on the server."

	echo "$ip"
}

create_domain() {
# This function creates a domain with given name and random username login.
# Domain does not redeployed if it exists already.
# #TODO#If a doman with given name already exists, it will be removed and created again.
# It is also creates a client and assigns the domain to him, if a Username is specified.
# First word from username will be taken as login, if no login is specified.
# Usage:
#
# create_domain "example.com" "John Trivolta" "john1234"
#

	local domain_name="$1"
	local CLIENT_NAME="$2"
	local CLIENT_LOGIN="$3"
	local ret

	test -z "$CLIENT_NAME" && CLIENT_NAME="admin" && CLIENT_LOGIN="admin"
	if [ "$CLIENT_NAME" != "admin" -a -z "$CLIENT_LOGIN" ] ; then 
		CLIENT_LOGIN="$(echo "$CLIENT_NAME" | awk '{print $1}' )" 
	fi 

	echo $(plesk bin client -l) | grep "$CLIENT_LOGIN" >>$output 2>&1
	test $? -eq 0 && plesk bin client --remove "$CLIENT_LOGIN" >>$output 2>&1
	local CLIENT_COMPANY="Acme"
	local CLIENT_EMAIL="$CLIENT_LOGIN@$domain_name"
	local CLIENT_PHONE="+1$RANDOM$RANDOM"
	plesk bin client --create "$CLIENT_LOGIN" -name "$CLIENT_NAME" -passwd "$(genpass)" \
		-company "$CLIENT_COMPANY" -email "$CLIENT_EMAIL" -phone "$CLIENT_PHONE" -notify false \
		-description "Priority customer. High attention required." 1>>$output 2>&1

	plesk bin subscription --create "$domain_name" -service-plan "Default Domain" \
		-ip "$(get_shared_ip)" -login "ftp_$RANDOM" -passwd "$(genpass)" \
		-owner "$CLIENT_LOGIN" >>$output 2>&1
	ret=$?

	if [ $ret -eq 0 -o $ret -eq 2 ] ; then
		return 0
	else
		die "Cannot create domain \"$domain_name\"."
	fi
}


kill_installer() {
# This function kills autoinstaller and installer instances.
#	
	killall -r '(auto)?installer' >>$output 2>&1
	rm -f /tmp/psa-installer.lock /tmp/autoinstaller_webui_socket
#	rm -r /tmp/pp-bootstrapper-*flag
}

usage() {
# This function lists available options 
# which are contained in a script file where it was invoked from.
# It assumes the following syntax of options: 
#
# ^<SPACE>"--option") # <PARAMETER><TAB>..<TAB><Option comment to display>
#
# Note1: '^' represents beginning of the line. 
#  	 '<SPACE>' represents multiple tabulation or space characters.
#	 '<PARAMETER>' is an optional parameter for option (i.e. PROBLEM_ID). 
# Note2: Number of <TAB>s between '#' and option comment depends on 
# option length and parameters, and may vary from 1 (for long names) to 3 or 4.
#
echo "Usage: "
grep -E '^[[:space:]]*"--.*"' $0 | sed "
	s@^[[:space:]]*[\"]@   $(basename "$0") @
	s@[\"][\)] \#@@"
}

check_args() {
# This function checks that there arguments passed to the script.
# In case of '--break', '--verify', and '--fix' options, it also checks that
# correct problem ID is passed to the script.
# Usage
#
# check_args $*
#

reqire_id="--break --verify --fix"
PROBLEMS=$(list_problems)

test -n "$1" || die "Parameter is required. Run with --help to list available parameters."

if [[ $reqire_id =~ (^|[[:space:]])$1($|[[:space:]]) ]] ; then
    if [ -z "$2" ] ; then
        echo -e "Problem ID is required.\n"
        list_problems -v
        exit 2

    elif ! echo $PROBLEMS | grep -qw $2  ; then
        echo -e "Unknown problem ID: '$2'\n"
        list_problems -v
        exit 3
    fi
fi
}